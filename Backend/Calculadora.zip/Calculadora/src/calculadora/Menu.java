
package calculadora;

import java.util.Scanner;

public class Menu {

	
	public static void main(String args[]) {
		Calculadora calcu = new Calculadora();
		Scanner scanner = new Scanner(System.in);
		int opcion;
		//
	while(true){ 
	    System.out.println("         Menu de calculadora:       ");
            System.out.println("1. Suma");
            System.out.println("2. Resta");
	    System.out.println("3. Multiplicacion");
            System.out.println("4. Division");
            System.out.println("5. Saliendo");
            System.out.print("Seleccione una opcion: ");
	    opcion = scanner.nextInt();
		switch (opcion){
			
			case 1 :
				System.out.println("Selecciono suma");
				System.out.println("Ingrese numero 1: ");
				int n = scanner.nextInt();
				calcu.setNum1(n);
				System.out.println("Ingrese numero 2: ");
				int n1 = scanner.nextInt();
				calcu.setNum2(n1);
				calcu.suma();
				
				break;
			case 2 : 
				System.out.println("Selecciono resta");
				System.out.println("Ingrese numero 1: ");
				int n2 = scanner.nextInt();
				calcu.setNum1(n2);
				System.out.println("Ingrese numero 2: ");
				int n3 = scanner.nextInt();
				calcu.setNum2(n3);
				calcu.resta();
				break;
			case 3 :
				System.out.println("Selecciono multiplicacion");
				System.out.println("Ingrese numero 1: ");
				int n4 = scanner.nextInt();
				calcu.setNum1(n4);
				System.out.println("Ingrese numero 2: ");
				int n5 = scanner.nextInt();
				calcu.setNum2(n5);
				calcu.multiplicacion();
				
				break;
			case 4 :
				System.out.println("Selecciono Division");
				System.out.println("Ingrese numero 1: ");
				int n6 = scanner.nextInt();
				calcu.setNum1(n6);
				System.out.println("Ingrese numero 2: ");
				int n7 = scanner.nextInt();
				calcu.setNum2(n7);
				calcu.division();
				
				break;
			case 5 :
				System.out.println("Saliendo");
				return;
			default : 
				System.out.println("Solo puede elegir una de las opciones");	
		}
		
	}
	}
	}

