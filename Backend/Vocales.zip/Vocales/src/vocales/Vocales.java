
package vocales;

public class Vocales {

	public static void main(String[] args) {
		String nombre = "Nicolas";
int a = 0, e = 0, i = 0, o = 0, u = 0;

for (int k = 0; k < nombre.length(); k++) {
    char vocal = nombre.toLowerCase().charAt(k);

    switch (vocal) {
        case 'a':
            a++;
            break;
        case 'e':
            e++;
            break;
        case 'i':
            i++;
            break;
        case 'o':
            o++;
            break;
        case 'u':
            u++;
            break;
        default:
            break;
    }
}

System.out.println("Total de vocales: " + (a+e+i+o+u));
		
	}	
}
