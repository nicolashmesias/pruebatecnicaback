package nombre;


public class Nombre {
	
	public static void main(String[] args) {
	String nombre = "pedro";
	String revez = "";
		System.out.println(nombre);
	for (int i = nombre.length()-1; i>=0; i-- ){
	 revez += nombre.charAt(i);	
	}
	System.out.println(revez);
	
	}		
}	
		
		
	
	
		
		
		
	
	

